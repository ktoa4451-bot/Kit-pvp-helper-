package com.kitpvp.glass;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

public final class Util {
    private Util() {}

    public static Vec3d pos(Entity e) {
        return new Vec3d(e.getX(), e.getY(), e.getZ());
    }

    public static Vec3d eye(Entity e) {
        return new Vec3d(e.getX(), e.getEyeY(), e.getZ());
    }

    public static String itemPath(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).getPath();
    }

    public static PlayerEntity nearestEnemy(MinecraftClient mc, double range) {
        PlayerEntity best = null;
        double bd = range * range;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || !o.isAlive() || o.isSpectator()) continue;
            double d = mc.player.squaredDistanceTo(o);
            if (d < bd) {
                bd = d;
                best = o;
            }
        }
        return best;
    }

    // ---- hotbar helpers ----
    private static int restoreSlot = -1;
    private static int restoreTicks = 0;

    public static int findHotbar(ClientPlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) {
            if (f.test(p.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    public static void select(ClientPlayerEntity p, int slot) {
        if (slot >= 0 && slot < 9) p.getInventory().setSelectedSlot(slot);
    }

    /** Temporarily switch slot, comes back after a few ticks. */
    public static void swapTemp(ClientPlayerEntity p, int slot) {
        int cur = p.getInventory().getSelectedSlot();
        if (slot == cur) return;
        if (restoreSlot < 0) restoreSlot = cur;
        p.getInventory().setSelectedSlot(slot);
        restoreTicks = 3;
    }

    public static void tickRestore(ClientPlayerEntity p) {
        if (restoreSlot >= 0 && --restoreTicks <= 0) {
            p.getInventory().setSelectedSlot(restoreSlot);
            restoreSlot = -1;
        }
    }
}
