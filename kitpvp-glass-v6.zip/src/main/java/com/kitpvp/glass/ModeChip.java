package com.kitpvp.glass;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Invisible click area for the mode chip; GlassCard draws the chip itself. */
public class ModeChip extends ButtonWidget {
    public ModeChip(int x, int y, int w, int h, Module module) {
        super(x, y, w, h, Text.literal(module.name + " mode"), b -> {
            module.mode = (module.mode + 1) % module.modes.length;
            Config.save();
        }, ButtonWidget.DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    public void renderWidget(DrawContext c, int mouseX, int mouseY, float delta) {
    }
}
