package com.kitpvp.glass;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public abstract class Module {
    public final String name;
    public final String description;
    public boolean enabled;
    /** Optional mode list (null = module has no modes). */
    public String[] modes;
    public int mode;

    protected Module(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void tick(MinecraftClient mc) {}

    /** Called right before the player attacks a living entity. */
    public void onAttack(MinecraftClient mc, ClientPlayerEntity p) {}
}
