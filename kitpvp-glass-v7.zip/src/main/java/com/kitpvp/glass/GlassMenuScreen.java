package com.kitpvp.glass;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class GlassMenuScreen extends Screen {
    private static final int W = 360;
    private static final int HEAD = 44;
    private static final int CARD_H = 36;
    private static final int GAP = 6;
    private static final int PAD = 16;

    private int px, py, ph;

    public GlassMenuScreen() {
        super(Text.literal("KitPvP Glass"));
    }

    @Override
    protected void init() {
        int n = ModuleManager.ALL.size();
        ph = HEAD + n * (CARD_H + GAP) - GAP + PAD + 12;
        px = (width - W) / 2;
        py = (height - ph) / 2;
        for (int i = 0; i < n; i++) {
            Module m = ModuleManager.ALL.get(i);
            int cx = px + PAD;
            int cy = py + HEAD + i * (CARD_H + GAP);
            int cw = W - 2 * PAD;
            if (m.modes != null) {
                // added first so it gets the click before the card; the card draws the chip
                addDrawableChild(new ModeChip(cx + cw - GlassCard.CHIP_OFFSET, cy + (CARD_H - GlassCard.CHIP_H) / 2,
                        GlassCard.CHIP_W, GlassCard.CHIP_H, m));
            }
            addDrawableChild(new GlassCard(cx, cy, cw, CARD_H, m));
        }
    }

    @Override
    public void renderBackground(DrawContext c, int mouseX, int mouseY, float delta) {
        super.renderBackground(c, mouseX, mouseY, delta); // blurred world behind
        Glass.surface(c, px, py, W, ph, 14, 0x34FFFFFF);
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        super.render(c, mouseX, mouseY, delta);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("KitPvP").formatted(Formatting.BOLD),
                width / 2, py + 14, 0xFFFFFFFF);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("ESC - close"),
                width / 2, py + ph - 16, 0xFFAEB9C4);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
