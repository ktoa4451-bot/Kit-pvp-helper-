package com.kitpvp.glass.modules;

import com.kitpvp.glass.Module;
import com.kitpvp.glass.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Mode "Rail":  you place a rail -> TNT minecart goes on it -> shot from bow/crossbow.
 * Mode "Arrow": you shoot an arrow -> where it lands the mod places a rail and a TNT minecart
 *               -> shot from bow/crossbow. (Landing spot must be within block reach.)
 * No bow/crossbow in the hotbar -> flint and steel / fire charge as a fallback.
 */
public class AutoCart extends Module {
    private static final int MODE_RAIL = 0;
    private static final int MODE_ARROW = 1;

    private int stage;
    private int wait;
    private int tries;
    private int charge;
    private BlockPos rail;
    private Entity cart;
    private boolean crossbow;
    private float oldYaw, oldPitch;

    // arrow tracking
    private int trackedId = -1;
    private Vec3d lastArrowPos;
    private int stillTicks;

    public AutoCart() {
        super("AutoCart", "Rail or arrow -> TNT cart + shot");
        modes = new String[]{"Rail", "Arrow"};
    }

    @Override
    public void onEnable() {
        stage = 0;
        wait = 0;
        trackedId = -1;
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.useKey.setPressed(false);
        stage = 0;
        wait = 0;
        cart = null;
        trackedId = -1;
    }

    /** Called by the use-block hook when the player right-clicks with a rail in hand. */
    public void onRailPlaced(MinecraftClient mc, BlockPos pos) {
        if (mode != MODE_RAIL || stage != 0 || wait > 0) return;
        if (Util.findHotbar(mc.player, s -> s.isOf(Items.TNT_MINECART)) < 0) return;
        rail = pos;
        stage = 1;
        wait = 0;
        tries = 0;
    }

    private void reset(MinecraftClient mc, int delay) {
        mc.options.useKey.setPressed(false);
        stage = 0;
        wait = delay;
        tries = 0;
        cart = null;
        trackedId = -1;
    }

    private void finish(MinecraftClient mc, ClientPlayerEntity p) {
        p.setYaw(oldYaw);
        p.setPitch(oldPitch);
        reset(mc, 30);
    }

    private void aim(ClientPlayerEntity p) {
        if (cart == null) return;
        Vec3d e = Util.eye(p);
        double dx = cart.getX() - e.x;
        double dy = cart.getY() + 0.35 - e.y;
        double dz = cart.getZ() - e.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setPitch((float) -Math.toDegrees(Math.atan2(dy, flat)));
    }

    private static boolean free(BlockState s) {
        return s.isAir() || s.isReplaceable();
    }

    // ---------------- arrow mode ----------------

    private void trackArrow(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;

        if (trackedId == -1) {
            for (Entity e : w.getEntities()) {
                if (e.getType() != EntityType.ARROW && e.getType() != EntityType.SPECTRAL_ARROW) continue;
                if (e.age > 5) continue; // only freshly shot arrows
                if (!(e instanceof ProjectileEntity pr) || pr.getOwner() != p) continue;
                trackedId = e.getId();
                lastArrowPos = Util.pos(e);
                stillTicks = 0;
                break;
            }
            return;
        }

        Entity a = w.getEntityById(trackedId);
        if (a == null || !a.isAlive()) {
            trackedId = -1;
            return;
        }
        Vec3d now = Util.pos(a);
        if (now.squaredDistanceTo(lastArrowPos) < 1.0E-6) stillTicks++;
        else stillTicks = 0;
        lastArrowPos = now;

        if (a.age > 2 && stillTicks >= 2) {
            trackedId = -1;
            landed(mc, a);
        }
    }

    private void landed(MinecraftClient mc, Entity arrow) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;

        if (Util.findHotbar(p, s -> Util.itemPath(s).endsWith("rail")) < 0) return;
        if (Util.findHotbar(p, s -> s.isOf(Items.TNT_MINECART)) < 0) return;

        BlockPos pos = BlockPos.ofFloored(arrow.getX(), arrow.getY(), arrow.getZ());
        // arrow sits inside the block it hit -> go up to free space
        for (int i = 0; i < 3 && !free(w.getBlockState(pos)); i++) pos = pos.up();
        // hanging in the air -> go down to the ground
        for (int i = 0; i < 3 && free(w.getBlockState(pos.down())); i++) pos = pos.down();

        if (!free(w.getBlockState(pos))) return;
        BlockPos below = pos.down();
        if (!w.getBlockState(below).isSideSolidFullSquare(w, below, Direction.UP)) return;

        Vec3d eye = Util.eye(p);
        Vec3d c = new Vec3d(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        if (eye.squaredDistanceTo(c) > 5.0 * 5.0) return; // out of block reach

        rail = pos;
        stage = 6;
        wait = 0;
        tries = 0;
    }

    // ---------------- main tick ----------------

    @Override
    public void tick(MinecraftClient mc) {
        if (wait > 0) {
            wait--;
            return;
        }
        if (stage == 0) {
            if (mode == MODE_ARROW) trackArrow(mc);
            return;
        }
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;

        switch (stage) {
            case 6 -> { // arrow mode: place the rail where the arrow landed
                int slot = Util.findHotbar(p, s -> Util.itemPath(s).endsWith("rail"));
                if (slot < 0) {
                    reset(mc, 10);
                    return;
                }
                Util.select(p, slot);
                BlockPos below = rail.down();
                BlockHitResult hit = new BlockHitResult(
                        new Vec3d(below.getX() + 0.5, below.getY() + 1.0, below.getZ() + 0.5),
                        Direction.UP, below, false);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
                p.swingHand(Hand.MAIN_HAND);
                stage = 1;
                tries = 0;
                wait = 1;
            }
            case 1 -> { // rail is placed -> put the TNT minecart on it
                if (!w.getBlockState(rail).isIn(BlockTags.RAILS)) {
                    if (++tries > 6) reset(mc, 10);
                    return;
                }
                int slot = Util.findHotbar(p, s -> s.isOf(Items.TNT_MINECART));
                if (slot < 0) {
                    reset(mc, 10);
                    return;
                }
                Util.select(p, slot);
                BlockHitResult hit = new BlockHitResult(
                        new Vec3d(rail.getX() + 0.5, rail.getY() + 0.1, rail.getZ() + 0.5),
                        Direction.UP, rail, false);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
                p.swingHand(Hand.MAIN_HAND);
                stage = 2;
                tries = 0;
            }
            case 2 -> { // wait for the cart entity, then aim
                List<Entity> carts = w.getOtherEntities(null, new Box(rail).expand(1.0),
                        e -> e.getType() == EntityType.TNT_MINECART);
                if (carts.isEmpty()) {
                    if (++tries > 12) reset(mc, 10);
                    return;
                }
                cart = carts.get(0);

                int bow = Util.findHotbar(p, s -> {
                    String n = Util.itemPath(s);
                    return n.equals("bow") || n.equals("crossbow");
                });
                if (bow < 0) { // fallback: ignite by hand
                    int fs = Util.findHotbar(p, s -> s.isOf(Items.FLINT_AND_STEEL) || s.isOf(Items.FIRE_CHARGE));
                    if (fs >= 0) {
                        Util.select(p, fs);
                        mc.interactionManager.interactEntity(p, cart, Hand.MAIN_HAND);
                        p.swingHand(Hand.MAIN_HAND);
                    }
                    reset(mc, 30);
                    return;
                }
                Util.select(p, bow);
                crossbow = Util.itemPath(p.getInventory().getStack(bow)).equals("crossbow");
                oldYaw = p.getYaw();
                oldPitch = p.getPitch();
                aim(p);
                stage = 3;
                wait = 1; // let the rotation reach the server
            }
            case 3 -> { // start drawing (or fire a loaded crossbow)
                aim(p);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                if (p.isUsingItem()) {
                    mc.options.useKey.setPressed(true); // keep drawing
                    charge = 0;
                    stage = 4;
                } else {
                    finish(mc, p);
                }
            }
            case 4 -> { // charge, then release
                aim(p);
                int need = crossbow ? 28 : 21;
                if (++charge >= need) {
                    mc.options.useKey.setPressed(false);
                    mc.interactionManager.stopUsingItem(p);
                    if (crossbow) {
                        stage = 5;
                        wait = 2;
                    } else {
                        finish(mc, p);
                    }
                }
            }
            case 5 -> { // crossbow is loaded now -> shoot
                aim(p);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                finish(mc, p);
            }
            default -> reset(mc, 0);
        }
    }
}
