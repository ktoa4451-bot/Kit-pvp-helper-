package com.kitpvp.glass.modules;

import com.kitpvp.glass.Module;
import com.kitpvp.glass.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;

/** Swaps to the mace for the hit while you are falling, then swaps back. */
public class MaceHelper extends Module {
    public MaceHelper() {
        super("MaceHelper", "Swaps to mace when you hit while falling");
    }

    @Override
    public void onAttack(MinecraftClient mc, ClientPlayerEntity p) {
        if (p.isOnGround() || p.getVelocity().y > -0.5) return;
        if (p.getMainHandStack().isOf(Items.MACE)) return;
        int slot = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        if (slot >= 0) Util.swapTemp(p, slot);
    }
}
