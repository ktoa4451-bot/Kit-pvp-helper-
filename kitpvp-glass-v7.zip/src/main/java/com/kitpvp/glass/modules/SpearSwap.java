package com.kitpvp.glass.modules;

import com.kitpvp.glass.Module;
import com.kitpvp.glass.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Bind a key (Controls -> KitPvP Glass). On press: take a spear from the hotbar,
 * hit the target in front of you, put the previous item back - all in one tick.
 */
public class SpearSwap extends Module {
    /** True while SpearSwap itself attacks, so other modules don't interfere. */
    public static boolean busy = false;

    public SpearSwap() {
        super("SpearSwap", "Key: spear swap (Hit/Lunge/Reach)");
        modes = new String[]{"Hit", "Lunge", "Reach"};
    }

    private Entity pickTarget(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        Entity t = mc.targetedEntity;
        if (t instanceof LivingEntity && t.isAlive()) return t;

        // spear reaches further than the vanilla crosshair check: look for a player in front
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d eye = Util.eye(p);
        Entity best = null;
        double bestDot = 0.975; // about 13 degrees
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            Vec3d to = new Vec3d(o.getX() - eye.x, o.getY() + o.getHeight() * 0.5 - eye.y, o.getZ() - eye.z);
            double dist = to.length();
            if (dist > 4.5 || dist < 0.1) continue;
            double dot = to.normalize().dotProduct(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = o;
            }
        }
        return best;
    }

    private void hit(MinecraftClient mc, ClientPlayerEntity p, Entity target) {
        mc.interactionManager.attackEntity(p, target); // syncs the slot first, then sends the attack
        p.swingHand(Hand.MAIN_HAND);
    }

    private static boolean isSpear(net.minecraft.item.ItemStack s) {
        return Util.itemPath(s).endsWith("_spear");
    }

    /** mace > axe > sword */
    private int findWeapon(ClientPlayerEntity p) {
        int w = Util.findHotbar(p, s -> Util.itemPath(s).equals("mace"));
        if (w < 0) w = Util.findHotbar(p, s -> Util.itemPath(s).endsWith("_axe"));
        if (w < 0) w = Util.findHotbar(p, s -> Util.itemPath(s).endsWith("_sword"));
        return w;
    }

    public void trigger(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        int spear = Util.findHotbar(p, SpearSwap::isSpear);
        if (spear < 0) return;
        Entity target = pickTarget(mc);
        if (target == null) return;

        int old = p.getInventory().getSelectedSlot();
        busy = true;
        try {
            switch (mode) {
                case 1 -> { // Lunge swap: hit with the current item, same tick jab with the spear
                    if (!isSpear(p.getInventory().getStack(old))) hit(mc, p, target);
                    p.getInventory().setSelectedSlot(spear);
                    hit(mc, p, target);
                }
                case 2 -> { // Reach swap: spear hit from far, same tick mace/axe/sword hit
                    p.getInventory().setSelectedSlot(spear);
                    hit(mc, p, target);
                    int w = findWeapon(p);
                    if (w >= 0) {
                        p.getInventory().setSelectedSlot(w);
                        hit(mc, p, target);
                    }
                }
                default -> { // Hit: spear hit, swap back
                    p.getInventory().setSelectedSlot(spear);
                    hit(mc, p, target);
                }
            }
        } finally {
            p.getInventory().setSelectedSlot(old);
            busy = false;
        }
    }
}
