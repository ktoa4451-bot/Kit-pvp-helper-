package com.kitpvp.glass.modules;

import com.kitpvp.glass.Module;
import com.kitpvp.glass.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Smart crystal helper:
 *  - picks the spot with the best (damage to enemy - damage to you) using an explosion damage estimate
 *  - breaks crystals every tick when it is worth it and safe
 *  - anti-suicide: stops on low health / without a totem, never pops crystals that would hurt you too much
 *  - mode "AutoObs": if there is no obsidian/bedrock spot, places obsidian first
 */
public class AutoCrystal extends Module {
    private static final double REACH = 4.5;
    private static final double MIN_TARGET_DMG = 4.0;  // don't bother below 2 hearts
    private static final double MAX_SELF_DMG = 8.0;    // max 4 hearts to ourselves
    private static final float MIN_HEALTH = 6.0f;      // anti-suicide: stop at 3 hearts
    private static final float MIN_HEALTH_NO_TOTEM = 10.0f;

    private int placeTimer;

    public AutoCrystal() {
        super("AutoCrystal", "Smart place/break + anti-suicide");
        modes = new String[]{"Normal", "AutoObs"};
    }

    // ---------- damage estimate (vanilla-like, simplified) ----------

    private static double damage(ClientWorld w, Vec3d crystal, LivingEntity e) {
        double dist = crystal.distanceTo(Util.pos(e)) / 12.0;
        if (dist > 1.0) return 0.0;
        Vec3d center = new Vec3d(e.getX(), e.getY() + e.getHeight() * 0.5, e.getZ());
        HitResult hr = w.raycast(new RaycastContext(crystal, center,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
        double exposure = hr.getType() == HitResult.Type.MISS ? 1.0 : 0.0;
        double impact = (1.0 - dist) * exposure;
        double dmg = (impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0;
        if (impact <= 0) return 0.0;

        switch (w.getDifficulty().getId()) {
            case 0 -> dmg = 0;
            case 1 -> dmg = Math.min(dmg / 2.0 + 1.0, dmg);
            case 3 -> dmg = dmg * 1.5;
            default -> { }
        }
        dmg *= 1.0 - Math.min(20, e.getArmor()) / 25.0; // armor only, enchantments ignored
        return dmg;
    }

    private static boolean hasTotem(ClientPlayerEntity p) {
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) || p.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            return true;
        }
        return Util.findHotbar(p, s -> s.isOf(Items.TOTEM_OF_UNDYING)) >= 0;
    }

    private static boolean noRoomIssue(ClientWorld w, BlockPos base) {
        Box box = new Box(base.getX(), base.getY() + 1, base.getZ(), base.getX() + 1, base.getY() + 3, base.getZ() + 1);
        return w.getOtherEntities(null, box).isEmpty();
    }

    // ---------- main ----------

    @Override
    public void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        PlayerEntity target = Util.nearestEnemy(mc, 12);
        if (target == null) return;

        // anti-suicide
        float hp = p.getHealth() + p.getAbsorptionAmount();
        if (hp <= MIN_HEALTH) return;
        if (!hasTotem(p) && hp <= MIN_HEALTH_NO_TOTEM) return;

        Vec3d eye = Util.eye(p);
        Vec3d selfPos = Util.pos(p);

        // 1) break - every tick
        Entity best = null;
        double bestScore = -Double.MAX_VALUE;
        for (Entity e : w.getEntities()) {
            if (e.getType() != EntityType.END_CRYSTAL || !e.isAlive()) continue;
            if (e.squaredDistanceTo(eye.x, eye.y, eye.z) > REACH * REACH) continue;
            Vec3d cp = Util.pos(e);
            double td = damage(w, cp, target);
            double sd = damage(w, cp, p);
            if (td < 1.0) continue;
            if (sd > MAX_SELF_DMG || sd >= hp - 2.0) continue;
            double score = td - sd;
            if (score > bestScore) {
                bestScore = score;
                best = e;
            }
        }
        if (best != null) {
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
            return;
        }

        // 2) place - every 2 ticks
        if (placeTimer-- > 0) return;
        placeTimer = 1;

        Hand hand = Hand.MAIN_HAND;
        boolean offhand = p.getOffHandStack().isOf(Items.END_CRYSTAL);
        int crystalSlot = -1;
        if (offhand) {
            hand = Hand.OFF_HAND;
        } else {
            crystalSlot = Util.findHotbar(p, s -> s.isOf(Items.END_CRYSTAL));
            if (crystalSlot < 0) return;
        }

        BlockPos tp = target.getBlockPos();
        BlockPos bestPos = null;
        double bestPosScore = -Double.MAX_VALUE;

        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -3; dy <= 1; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    BlockPos bp = tp.add(dx, dy, dz);
                    BlockState st = w.getBlockState(bp);
                    if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) continue;
                    if (!w.getBlockState(bp.up()).isAir() || !w.getBlockState(bp.up(2)).isAir()) continue;
                    Vec3d c = new Vec3d(bp.getX() + 0.5, bp.getY() + 1.0, bp.getZ() + 0.5);
                    if (eye.squaredDistanceTo(c) > REACH * REACH) continue;
                    if (c.distanceTo(selfPos) < 2.0) continue;
                    if (!noRoomIssue(w, bp)) continue;
                    double td = damage(w, c, target);
                    double sd = damage(w, c, p);
                    if (td < MIN_TARGET_DMG || sd > MAX_SELF_DMG || sd >= hp - 2.0) continue;
                    double score = td - sd;
                    if (score > bestPosScore) {
                        bestPosScore = score;
                        bestPos = bp;
                    }
                }
            }
        }

        if (bestPos != null) {
            if (!offhand) Util.select(p, crystalSlot);
            BlockHitResult hit = new BlockHitResult(
                    new Vec3d(bestPos.getX() + 0.5, bestPos.getY() + 1.0, bestPos.getZ() + 0.5),
                    Direction.UP, bestPos, false);
            mc.interactionManager.interactBlock(p, hand, hit);
            p.swingHand(hand);
            return;
        }

        // 3) AutoObsidian: no obsidian/bedrock spot -> put an obsidian block where a crystal would be good
        if (mode != 1) return;
        int obsSlot = Util.findHotbar(p, s -> s.isOf(Items.OBSIDIAN));
        if (obsSlot < 0) return;

        BlockPos bestObs = null;
        double bestObsScore = -Double.MAX_VALUE;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -3; dy <= 1; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    BlockPos b = tp.add(dx, dy, dz);
                    if (!w.getBlockState(b).isAir()) continue;
                    BlockPos below = b.down();
                    if (!w.getBlockState(below).isSideSolidFullSquare(w, below, Direction.UP)) continue;
                    if (!w.getBlockState(b.up()).isAir() || !w.getBlockState(b.up(2)).isAir()) continue;
                    Vec3d bc = new Vec3d(b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5);
                    if (eye.squaredDistanceTo(bc) > REACH * REACH) continue;
                    Vec3d c = new Vec3d(b.getX() + 0.5, b.getY() + 1.0, b.getZ() + 0.5);
                    if (c.distanceTo(selfPos) < 2.0) continue;
                    if (!w.getOtherEntities(null, new Box(b)).isEmpty() || !noRoomIssue(w, b)) continue;
                    double td = damage(w, c, target);
                    double sd = damage(w, c, p);
                    if (td < MIN_TARGET_DMG || sd > MAX_SELF_DMG || sd >= hp - 2.0) continue;
                    double score = td - sd - 2.0; // existing obsidian is preferred
                    if (score > bestObsScore) {
                        bestObsScore = score;
                        bestObs = b;
                    }
                }
            }
        }
        if (bestObs != null) {
            Util.select(p, obsSlot);
            BlockPos below = bestObs.down();
            BlockHitResult hit = new BlockHitResult(
                    new Vec3d(bestObs.getX() + 0.5, bestObs.getY(), bestObs.getZ() + 0.5),
                    Direction.UP, below, false);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
