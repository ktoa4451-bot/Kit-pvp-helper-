package com.kitpvp.glass;

import com.kitpvp.glass.modules.AutoCart;
import com.kitpvp.glass.modules.AutoCrystal;
import com.kitpvp.glass.modules.MaceHelper;
import com.kitpvp.glass.modules.SpearSwap;
import net.minecraft.client.MinecraftClient;

import java.util.List;

public final class ModuleManager {
    public static final MaceHelper MACE_HELPER = new MaceHelper();
    public static final SpearSwap SPEAR_SWAP = new SpearSwap();
    public static final AutoCart AUTO_CART = new AutoCart();

    public static final List<Module> ALL = List.of(
            AUTO_CART,
            new AutoCrystal(),
            SPEAR_SWAP,
            MACE_HELPER
    );

    private ModuleManager() {}

    public static void tick(MinecraftClient mc) {
        Util.tickRestore(mc.player);
        for (Module m : ALL) {
            if (m.enabled) m.tick(mc);
        }
    }

    public static void onAttack(MinecraftClient mc) {
        if (SpearSwap.busy) return;
        if (MACE_HELPER.enabled) MACE_HELPER.onAttack(mc, mc.player);
    }
}
