package com.kitpvp.glass;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public class KitPvpClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding spearKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        // GLFW_KEY_GRAVE_ACCENT = физическая клавиша "ё" / "~"
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("kitpvpglass", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kitpvpglass.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_GRAVE_ACCENT,
                category
        ));

        // default R, change in Controls -> KitPvP Glass
        spearKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kitpvpglass.spearswap",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (spearKey.wasPressed()) {
                if (client.currentScreen == null && client.player != null && client.interactionManager != null
                        && ModuleManager.SPEAR_SWAP.enabled) {
                    ModuleManager.SPEAR_SWAP.trigger(client);
                }
            }
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new GlassMenuScreen());
                }
            }
            if (client.player == null || client.world == null || client.interactionManager == null) return;
            if (client.currentScreen != null) return;
            ModuleManager.tick(client);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient() || !(entity instanceof LivingEntity)) return ActionResult.PASS;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.currentScreen != null) return ActionResult.PASS;
            ModuleManager.onAttack(mc);
            return ActionResult.PASS;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient() || !ModuleManager.AUTO_CART.enabled) return ActionResult.PASS;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.currentScreen != null || player != mc.player) return ActionResult.PASS;
            if (!Util.itemPath(player.getStackInHand(hand)).endsWith("rail")) return ActionResult.PASS;
            BlockPos clicked = hit.getBlockPos();
            BlockPos pos = world.getBlockState(clicked).isReplaceable() ? clicked : clicked.offset(hit.getSide());
            ModuleManager.AUTO_CART.onRailPlaced(mc, pos);
            return ActionResult.PASS;
        });
    }
}
