package com.kitpvp.glass;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;

/** One module card: name, description, optional mode chip and an on/off switch. */
public class GlassCard extends ButtonWidget {
    public static final int CHIP_W = 56;
    public static final int CHIP_H = 14;
    public static final int CHIP_OFFSET = 106; // from the card's right edge

    private final Module module;

    public GlassCard(int x, int y, int w, int h, Module module) {
        super(x, y, w, h, Util.text(module.name), b -> {
            module.toggle();
            Config.save();
        }, ButtonWidget.DEFAULT_NARRATION_SUPPLIER);
        this.module = module;
        this.setAlpha(0f); // hide the vanilla button texture, we draw our own glass
    }

    @Override
    public void drawIcon(DrawContext c, int mouseX, int mouseY, float delta) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        boolean on = module.enabled;

        int body = on ? 0x4A3FE0C5 : 0x26FFFFFF;
        if (isHovered()) body = on ? 0x6A4FF0D5 : 0x3CFFFFFF;
        Glass.surface(c, x, y, w, h, 8, body);

        c.drawTextWithShadow(tr, Util.text(module.name), x + 12, y + 7, 0xFFFFFFFF);
        c.drawTextWithShadow(tr, Util.text(module.description), x + 12, y + 21, on ? 0xFFD6FFF7 : 0xFFAEB9C4);

        // mode chip
        if (module.modes != null) {
            int cx = x + w - CHIP_OFFSET;
            int cy = y + (h - CHIP_H) / 2;
            boolean chipHover = mouseX >= cx && mouseX < cx + CHIP_W && mouseY >= cy && mouseY < cy + CHIP_H;
            Glass.rrect(c, cx, cy, CHIP_W, CHIP_H, 6, chipHover ? 0x80FFFFFF : 0x48FFFFFF);
            c.drawCenteredTextWithShadow(tr, Util.text(module.modes[module.mode]), cx + CHIP_W / 2, cy + 3, 0xFFFFFFFF);
        }

        // switch
        int sw = 30, sh = 14;
        int sx = x + w - sw - 12, sy = y + (h - sh) / 2;
        Glass.rrect(c, sx, sy, sw, sh, 7, on ? 0xFF35D8BE : 0x55FFFFFF);
        int kx = on ? sx + sw - 12 : sx + 2;
        Glass.rrect(c, kx, sy + 2, 10, 10, 5, 0xFFFFFFFF);
    }
}
