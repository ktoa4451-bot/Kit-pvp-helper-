package com.kitpvp.glass;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("kitpvpglass.properties");
    }

    public static void load() {
        Properties pr = new Properties();
        try (InputStream in = Files.newInputStream(file())) {
            pr.load(in);
        } catch (IOException ignored) {
        }
        for (Module m : ModuleManager.ALL) {
            m.enabled = Boolean.parseBoolean(pr.getProperty(m.name, "false"));
            if (m.modes != null) {
                try {
                    int v = Integer.parseInt(pr.getProperty(m.name + ".mode", "0"));
                    m.mode = (v >= 0 && v < m.modes.length) ? v : 0;
                } catch (NumberFormatException e) {
                    m.mode = 0;
                }
            }
        }
    }

    public static void save() {
        Properties pr = new Properties();
        for (Module m : ModuleManager.ALL) {
            pr.setProperty(m.name, Boolean.toString(m.enabled));
            if (m.modes != null) pr.setProperty(m.name + ".mode", Integer.toString(m.mode));
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            pr.store(out, "KitPvP Glass");
        } catch (IOException ignored) {
        }
    }
}
