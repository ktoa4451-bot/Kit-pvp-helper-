package com.kitpvp.glass;

import net.minecraft.client.gui.DrawContext;

/** Small helpers to draw the "glass" look with plain fills. */
public final class Glass {
    private Glass() {}

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (r < 1) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        for (int i = 0; i < h; i++) {
            double dy = 0;
            if (i < r) dy = r - i - 0.5;
            else if (i >= h - r) dy = i - (h - r) + 0.5;
            int inset = 0;
            if (dy > 0) {
                inset = r - (int) Math.floor(Math.sqrt(Math.max(0, r * r - dy * dy)));
            }
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
        }
    }

    /** Frosted glass surface: soft shadow, translucent body, light top highlight, thin bright edges. */
    public static void surface(DrawContext c, int x, int y, int w, int h, int r, int body) {
        rrect(c, x + 1, y + 3, w, h, r, 0x38000000);
        rrect(c, x, y, w, h, r, body);
        rrect(c, x + 1, y + 1, w - 2, Math.max(2, h / 3), Math.max(1, r - 1), 0x16FFFFFF);
        c.fill(x + r, y, x + w - r, y + 1, 0xA0FFFFFF);
        c.fill(x + r, y + h - 1, x + w - r, y + h, 0x40FFFFFF);
        c.fill(x, y + r, x + 1, y + h - r, 0x60FFFFFF);
        c.fill(x + w - 1, y + r, x + w, y + h - r, 0x60FFFFFF);
    }
}
